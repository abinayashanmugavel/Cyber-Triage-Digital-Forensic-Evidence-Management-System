from flask import Flask, render_template, request, send_file, redirect, session
import os
import hashlib
import datetime
import sqlite3
from reportlab.pdfgen import canvas


app = Flask(__name__)

app.secret_key = "CyberTriage123"

DATABASE = "cybertriage.db"

UPLOAD_FOLDER = "evidence"

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER


if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)



def get_db():

    return sqlite3.connect(DATABASE)



def init_db():

    conn = get_db()

    cursor = conn.cursor()


    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users(

        userid INTEGER PRIMARY KEY,
        username TEXT UNIQUE,
        password TEXT

    )
    """)


    cursor.execute("""
    CREATE TABLE IF NOT EXISTS investigations(

        id INTEGER PRIMARY KEY AUTOINCREMENT,
        userid INTEGER,
        filename TEXT,
        filesize TEXT,
        created_time TEXT,
        modified_time TEXT,
        sha256 TEXT,
        status TEXT

    )
    """)


    conn.commit()

    conn.close()



init_db()

@app.route("/home")
def landing():

    return render_template("index.html")

@app.route("/register", methods=["GET","POST"])
def register():


    if request.method=="POST":


        userid=request.form["userid"]

        username=request.form["username"]

        password=request.form["password"]



        password=hashlib.sha256(
            password.encode()
        ).hexdigest()



        conn=get_db()

        cursor=conn.cursor()


        cursor.execute(
        "INSERT INTO users(userid,username,password) VALUES(?,?,?)",
        (userid,username,password)
        )


        conn.commit()

        conn.close()


        return redirect("/login")



    return render_template("register.html")






@app.route("/login", methods=["GET","POST"])
def login():


    if request.method=="POST":


        userid=request.form["userid"]

        username=request.form["username"]

        password=request.form["password"]



        password=hashlib.sha256(
            password.encode()
        ).hexdigest()



        conn=get_db()

        cursor=conn.cursor()



        cursor.execute(
        "SELECT * FROM users WHERE userid=? AND username=? AND password=?",
        (userid,username,password)
        )


        user=cursor.fetchone()


        conn.close()



        if user:


            session["userid"]=userid

            session["user"]=username


            return redirect("/")


        else:

            return "Invalid Login"



    return render_template("login.html")






@app.route("/")
def home():


    if "userid" not in session:

        return redirect("/login")



    conn=get_db()

    cursor=conn.cursor()



    cursor.execute(
    "SELECT COUNT(*) FROM investigations WHERE userid=?",
    (session["userid"],)
    )


    total=cursor.fetchone()[0]



    cursor.execute(
    "SELECT COUNT(*) FROM investigations WHERE userid=? AND status=?",
    (session["userid"],"Analysis Completed")
    )


    completed=cursor.fetchone()[0]



    conn.close()



    return render_template(
        "dashboard.html",
        total=total,
        completed=completed
    )






@app.route("/investigation")
def investigation():

    if "userid" not in session:
        return redirect("/login")


    return render_template("upload.html")







@app.route("/upload", methods=["POST"])
def upload():

    if "userid" not in session:
        return redirect("/login")


    file = request.files["file"]


    if file.filename == "":
        return "No file selected"



    filepath = os.path.join(
        UPLOAD_FOLDER,
        file.filename
    )


    file.save(filepath)



    sha256 = hashlib.sha256()


    with open(filepath,"rb") as f:

        for chunk in iter(lambda:f.read(4096), b""):

            sha256.update(chunk)



    file_hash = sha256.hexdigest()



    size = os.path.getsize(filepath)



    created = datetime.datetime.fromtimestamp(
        os.path.getctime(filepath)
    )


    modified = datetime.datetime.fromtimestamp(
        os.path.getmtime(filepath)
    )



    conn = get_db()

    cursor = conn.cursor()



    cursor.execute("""

    INSERT INTO investigations

    (userid,filename,filesize,created_time,modified_time,sha256,status)

    VALUES(?,?,?,?,?,?,?)

    """,

    (

        session["userid"],
        file.filename,
        size,
        str(created),
        str(modified),
        file_hash,
        "Analysis Completed"

    ))



    conn.commit()

    conn.close()



    return render_template(

        "result.html",

        filename=file.filename,

        filesize=size,

        sha256=file_hash

    )

@app.route("/report/<int:id>")
def report(id):
    

    if "userid" not in session:
        return redirect("/login")


    conn = get_db()

    cursor = conn.cursor()


    cursor.execute(
        "SELECT * FROM investigations WHERE id=?",
        (id,)
    )


    data = cursor.fetchone()


    conn.close()



    pdf_name = f"Investigation_Report_{id}.pdf"


    pdf = canvas.Canvas(pdf_name)



    pdf.drawString(
        100,
        750,
        "CyberTriage Investigation Report"
    )


    pdf.drawString(
        100,
        710,
        f"Investigator : {session['user']}"
    )


    pdf.drawString(
        100,
        670,
        f"Investigation ID : {id}"
    )


    pdf.drawString(
        100,
        630,
        f"File Name : {data[2]}"
    )


    pdf.drawString(
        100,
        600,
        f"File Size : {data[3]}"
    )


    pdf.drawString(
        100,
        570,
        f"SHA256 : {data[6]}"
    )


    pdf.drawString(
        100,
        540,
        f"Status : {data[7]}"
    )


    pdf.save()



    return send_file(
        pdf_name,
        as_attachment=True
    )





@app.route("/history")
def history():
    if "userid" not in session:
        return redirect("/login")


    conn=get_db()

    cursor=conn.cursor()



    cursor.execute(
    "SELECT * FROM investigations WHERE userid=?",
    (session["userid"],)
    )


    data=cursor.fetchall()


    conn.close()



    return render_template(
    "history.html",
    investigations=data
    )


@app.route("/delete/<int:id>")
def delete(id):

    if "userid" not in session:
        return redirect("/login")


    conn = get_db()

    cursor = conn.cursor()


    cursor.execute(
        "SELECT filename FROM investigations WHERE id=? AND userid=?",
        (id, session["userid"])
    )


    data = cursor.fetchone()



    if data:


        filepath = os.path.join(
            UPLOAD_FOLDER,
            data[0]
        )


        if os.path.exists(filepath):

            os.remove(filepath)



        cursor.execute(
            "DELETE FROM investigations WHERE id=? AND userid=?",
            (id, session["userid"])
        )


        conn.commit()



    conn.close()


    return redirect("/history")



@app.route("/logout")
def logout():

    session.clear()

    return """
    <script>
    alert("Logged out successfully");
    window.location="/login";
    </script>
    """





if __name__=="__main__":


    app.run(debug=True)